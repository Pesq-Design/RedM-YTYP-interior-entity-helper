import xml.etree.ElementTree as ET
from tkinter import Tk, Text, Button, Label, Entry, END, filedialog, ttk

# Function to find line numbers for <CEntityDef>
def find_entitydef_line_numbers(file_path):
    """Find the line numbers where <CEntityDef> tags start."""
    entitydef_lines = []
    with open(file_path, "r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            if "<Item type=\"CEntityDef\">" in line.strip():
                entitydef_lines.append(line_number)
    return entitydef_lines

# Function to parse the XML file
def parse_xml_with_line_numbers(file_path):
    """Parse the XML file and associate each <CEntityDef> with its line number and index."""
    # Step 1: Find line numbers for <CEntityDef>
    entitydef_lines = find_entitydef_line_numbers(file_path)

    # Step 2: Parse the XML file
    tree = ET.parse(file_path)
    root = tree.getroot()

    # Step 3: Extract <CEntityDef> items
    entities = []
    for index, entity in enumerate(root.findall(".//entities/Item[@type='CEntityDef']")):
        archetype_name = entity.findtext("archetypeName", default="N/A")
        entity_id = entity.find("id").get("value", "N/A") if entity.find("id") is not None else "N/A"
        position = entity.find("position")
        pos_x = position.get("x", "N/A") if position is not None else "N/A"
        pos_y = position.get("y", "N/A") if position is not None else "N/A"
        pos_z = position.get("z", "N/A") if position is not None else "N/A"

        # Include the line number and index
        line_number = entitydef_lines[index] if index < len(entitydef_lines) else "Unknown"

        entities.append({
            "index": index,
            "line_number": line_number,
            "archetypeName": archetype_name,
            "id": entity_id,
            "position": (pos_x, pos_y, pos_z),
            "xml_chunk": ET.tostring(entity, encoding="unicode")  # Store the full XML chunk
        })

    # Step 4: Extract <attachedObjects> arrays from <rooms>
    rooms = {}
    for room in root.findall(".//rooms/Item"):
        room_name = room.findtext("name", default="N/A")
        attached_objects = room.findtext("attachedObjects", default="").strip().split()
        rooms[room_name] = attached_objects

    # Step 5: Extract <attachedObjects> arrays from <portals>
    portals = {}
    for portal in root.findall(".//portals/Item"):
        portal_key = f"Portal_{len(portals) + 1}"  # Generate a unique key for each portal
        attached_objects = portal.findtext("attachedObjects", default="").strip().split()
        portals[portal_key] = attached_objects

    return entities, rooms, portals, tree


# Function to simulate deletion
def simulate_deletion(entities, rooms, portals, archetype, index):
    """Simulate the deletion of an entity."""
    try:
        index = int(index)
    except ValueError:
        return "Invalid index. Please enter a valid integer."
    # Find the entity to delete
    if index < 0 or index >= len(entities):
        return "Index out of range."
    if entities[index]["archetypeName"] != archetype:
        return f"No entity with Archetype '{archetype}' and Index {index} found."
    # Simulate deletion
    updated_entities = entities[:index] + entities[index + 1:]
    updated_rooms = {}
    updated_portals = {}
    # Update rooms
    for room, objects in rooms.items():
        updated_objects = []
        for obj in objects:
            obj_index = int(obj)
            if obj_index == index:
                continue  # Remove the deleted entity
            elif obj_index > index:
                updated_objects.append(str(obj_index - 1))  # Decrement subsequent indexes
            else:
                updated_objects.append(obj)
        updated_rooms[room] = updated_objects
    # Update portals
    for portal, objects in portals.items():
        updated_objects = []
        for obj in objects:
            obj_index = int(obj)
            if obj_index == index:
                continue  # Remove the deleted entity
            elif obj_index > index:
                updated_objects.append(str(obj_index - 1))  # Decrement subsequent indexes
            else:
                updated_objects.append(obj)
        updated_portals[portal] = updated_objects
    # Prepare the output
    output = "Changes to be made:\n"
    output += f"- Deleting entity: Archetype='{archetype}', Index={index}\n"
    output += "- Updated entities:\n"
    for i, entity in enumerate(updated_entities):
        output += f"  Index {i}: Archetype='{entity['archetypeName']}'\n"
    output += "- Updated rooms:\n"
    for room, objects in updated_rooms.items():
        formatted_attached_objects = reformat_attached_objects(list(map(int, objects)))
        output += f"  Room '{room}'\n<attachedObjects>\n{formatted_attached_objects}\n"
    output += "- Updated portals:\n"
    for portal, objects in updated_portals.items():
        formatted_attached_objects = reformat_attached_objects(list(map(int, objects)))
        output += f"  {portal}\n<attachedObjects>\n{formatted_attached_objects}\n"
    return output

# Function to search for an entity
def search_entity(entities, rooms, portals, search_term):
    """Search for an entity by ID, Index, or Archetype Name."""
    results = []

    # Check if the search term is an index
    try:
        search_index = int(search_term)
        search_by_index = True
    except ValueError:
        search_by_index = False

    for entity in entities:
        # Match by ID
        if search_term.lower() == entity["id"].lower():
            match_found = True
        # Match by Index
        elif search_by_index and entity["index"] == search_index:
            match_found = True
        # Match by Archetype Name
        elif search_term.lower() == entity["archetypeName"].lower():
            match_found = True
        else:
            match_found = False

        if match_found:
            # Find rooms and portals where the entity is attached
            attached_rooms = [room for room, objects in rooms.items() if str(entity["index"]) in objects]
            attached_portals = [portal for portal, objects in portals.items() if str(entity["index"]) in objects]

            results.append({
                "index": entity["index"],
                "archetypeName": entity["archetypeName"],
                "id": entity["id"],
                "xml_chunk": entity["xml_chunk"],
                "attached_rooms": attached_rooms,
                "attached_portals": attached_portals
            })

    return results

# GUI Setup
def upload_file(info_text):
    """Handle file upload via file dialog."""
    global parsed_entities, parsed_rooms, parsed_portals, parsed_tree
    file_path = filedialog.askopenfilename(
        title="Upload .ytyp File",
        filetypes=[("XML Files", "*.xml"), ("All Files", "*.*")]
    )
    if not file_path:
        info_text.insert(END, "File upload canceled.\n")
        return

    try:
        parsed_entities, parsed_rooms, parsed_portals, parsed_tree = parse_xml_with_line_numbers(file_path)
        info_text.delete(1.0, END)
        info_text.insert(END, "File Uploaded and Parsed Successfully!\n\n")
        for item in parsed_entities:
            info_text.insert(END, f"Line {item['line_number']}, Index: {item['index']}, "
                                  f"Archetype: {item['archetypeName']}, ID: {item['id']}\n")

        # Store parsed data in the display_information function
        display_information.parsed_entities = parsed_entities
        display_information.parsed_rooms = parsed_rooms
        display_information.parsed_portals = parsed_portals
    except Exception as e:
        info_text.insert(END, f"Failed to parse file: {e}\n")

def show_changes(delete_tab_text, archetype_entry, index_entry):
    """Show the changes that would be made if the entity is deleted."""
    archetype = archetype_entry.get().strip()
    index = index_entry.get().strip()

    if not archetype or not index:
        delete_tab_text.delete(1.0, END)
        delete_tab_text.insert(END, "Please enter both Archetype and Index.\n")
        return

    changes = simulate_deletion(parsed_entities, parsed_rooms, parsed_portals, archetype, index)
    delete_tab_text.delete(1.0, END)
    delete_tab_text.insert(END, changes)

def display_information(information_tab_text):
    """Display information about the parsed file."""
    if not hasattr(display_information, "parsed_entities") or not hasattr(display_information, "parsed_rooms") or not hasattr(display_information, "parsed_portals"):
        information_tab_text.insert(END, "No file has been uploaded yet.\n")
        return
    # Total number of entities
    total_entities = len(display_information.parsed_entities)
    # Rooms and their attachedObjects arrays
    rooms_info = ""
    for room, objects in display_information.parsed_rooms.items():
        formatted_attached_objects = reformat_attached_objects(list(map(int, objects)))
        rooms_info += f"Room '{room}'\n<attachedObjects>\n{formatted_attached_objects}\n"
    # Portals and their attachedObjects arrays
    portals_info = ""
    for portal, objects in display_information.parsed_portals.items():
        formatted_attached_objects = reformat_attached_objects(list(map(int, objects)))
        portals_info += f"{portal}\n<attachedObjects>\n{formatted_attached_objects}\n"
    # Display the information
    information_tab_text.delete(1.0, END)
    information_tab_text.insert(END, f"Total Entities: {total_entities}\n")
    information_tab_text.insert(END, "Rooms:\n")
    information_tab_text.insert(END, rooms_info)
    information_tab_text.insert(END, "\nPortals:\n")
    information_tab_text.insert(END, portals_info)

def search_entities(search_tab_text, search_entry):
    """Search for an entity and display the results."""
    if not hasattr(display_information, "parsed_entities") or not hasattr(display_information, "parsed_rooms") or not hasattr(display_information, "parsed_portals"):
        search_tab_text.insert(END, "No file has been uploaded yet.\n")
        return

    search_term = search_entry.get().strip()
    if not search_term:
        search_tab_text.insert(END, "Please enter an ID, Index, or Archetype Name to search.\n")
        return

    results = search_entity(display_information.parsed_entities, display_information.parsed_rooms, display_information.parsed_portals, search_term)

    if not results:
        search_tab_text.insert(END, "No matching entities found.\n")
        return

    # Display the results
    search_tab_text.delete(1.0, END)
    for result in results:
        search_tab_text.insert(END, f"Index: {result['index']}\n")
        search_tab_text.insert(END, f"Archetype: {result['archetypeName']}\n")
        search_tab_text.insert(END, f"ID: {result['id']}\n")
        search_tab_text.insert(END, "Attached Rooms:\n")
        for room in result["attached_rooms"]:
            search_tab_text.insert(END, f"  - {room}\n")
        search_tab_text.insert(END, "Attached Portals:\n")
        for portal in result["attached_portals"]:
            search_tab_text.insert(END, f"  - {portal}\n")
        search_tab_text.insert(END, "Entity Chunk:\n")
        search_tab_text.insert(END, f"{result['xml_chunk']}\n\n")

 # Function to reformat attachedObjects
def reformat_attached_objects(attached_objects):
    """
    Reformats the attachedObjects section into rows of 10 numbers.
    
    Args:
        attached_objects (list): A list of integers representing the attached objects.
    
    Returns:
        str: The reformatted <attachedObjects> section as a string.
    """
    # Split the numbers into rows of 10
    rows = [attached_objects[i:i + 10] for i in range(0, len(attached_objects), 10)]
    
    # Convert each row to a space-separated string, prefixed with 6 spaces for alignment
    formatted_rows = ["      " + " ".join(map(str, row)) for row in rows]
    
    # Join all rows with newlines and add the closing tag
    formatted_output = "\n".join(formatted_rows) + "\n     </attachedObjects>"
    
    return formatted_output

# Main App
root = Tk()
root.title("RedM YTYP Parser")

# Tabs
tab_control = ttk.Notebook(root)

upload_tab = ttk.Frame(tab_control)
delete_tab = ttk.Frame(tab_control)
information_tab = ttk.Frame(tab_control)
search_tab = ttk.Frame(tab_control)

tab_control.add(upload_tab, text="Upload")
tab_control.add(delete_tab, text="Delete")
tab_control.add(information_tab, text="Information")
tab_control.add(search_tab, text="Search")
tab_control.pack(expand=1, fill="both")

# Upload Tab
upload_frame = ttk.Frame(upload_tab)
upload_frame.pack(fill="both", expand=True)

info_text = Text(upload_frame, wrap="word", height=20, width=100)
scrollbar_upload = ttk.Scrollbar(upload_frame, orient="vertical", command=info_text.yview)
info_text.config(yscrollcommand=scrollbar_upload.set)

info_text.grid(row=0, column=0, sticky="nsew")
scrollbar_upload.grid(row=0, column=1, sticky="ns")

upload_frame.grid_rowconfigure(0, weight=1)
upload_frame.grid_columnconfigure(0, weight=1)

upload_button = Button(upload_tab, text="Upload File", command=lambda: upload_file(info_text))
upload_button.pack(pady=10)

# Delete Tab
delete_frame = ttk.Frame(delete_tab)
delete_frame.pack(fill="both", expand=True)

Label(delete_tab, text="Archetype:").pack(pady=5)
archetype_entry = Entry(delete_tab, width=50)
archetype_entry.pack(pady=5)

Label(delete_tab, text="Index:").pack(pady=5)
index_entry = Entry(delete_tab, width=50)
index_entry.pack(pady=5)

delete_tab_text = Text(delete_frame, wrap="word", height=20, width=100)
scrollbar_delete = ttk.Scrollbar(delete_frame, orient="vertical", command=delete_tab_text.yview)
delete_tab_text.config(yscrollcommand=scrollbar_delete.set)

delete_tab_text.grid(row=0, column=0, sticky="nsew")
scrollbar_delete.grid(row=0, column=1, sticky="ns")

delete_frame.grid_rowconfigure(0, weight=1)
delete_frame.grid_columnconfigure(0, weight=1)

show_button = Button(delete_tab, text="Show Changes",
                     command=lambda: show_changes(delete_tab_text, archetype_entry, index_entry))
show_button.pack(pady=10)

# Information Tab
info_frame = ttk.Frame(information_tab)
info_frame.pack(fill="both", expand=True)

information_tab_text = Text(info_frame, wrap="word", height=20, width=100)
scrollbar_info = ttk.Scrollbar(info_frame, orient="vertical", command=information_tab_text.yview)
information_tab_text.config(yscrollcommand=scrollbar_info.set)

information_tab_text.grid(row=0, column=0, sticky="nsew")
scrollbar_info.grid(row=0, column=1, sticky="ns")

info_frame.grid_rowconfigure(0, weight=1)
info_frame.grid_columnconfigure(0, weight=1)

display_info_button = Button(information_tab, text="Display Information",
                             command=lambda: display_information(information_tab_text))
display_info_button.pack(pady=10)

# Search Tab
search_frame = ttk.Frame(search_tab)
search_frame.pack(fill="both", expand=True)

Label(search_tab, text="Search by ID, Index, or Archetype Name:").pack(pady=5)
search_entry = Entry(search_tab, width=50)
search_entry.pack(pady=5)

search_tab_text = Text(search_frame, wrap="word", height=20, width=100)
scrollbar_search = ttk.Scrollbar(search_frame, orient="vertical", command=search_tab_text.yview)
search_tab_text.config(yscrollcommand=scrollbar_search.set)

search_tab_text.grid(row=0, column=0, sticky="nsew")
scrollbar_search.grid(row=0, column=1, sticky="ns")

search_frame.grid_rowconfigure(0, weight=1)
search_frame.grid_columnconfigure(0, weight=1)

search_button = Button(search_tab, text="Search",
                       command=lambda: search_entities(search_tab_text, search_entry))
search_button.pack(pady=10)

# Exit Button
exit_button = Button(root, text="Exit", command=root.quit)
exit_button.pack(side="bottom", pady=10)

# Run the app
root.mainloop()
